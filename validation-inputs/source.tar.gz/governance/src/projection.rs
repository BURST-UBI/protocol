use crate::{DelegationEngine, GovernanceEngine, GovernancePhase, Proposal};
use burst_types::{ProtocolParams, Timestamp, TxHash, WalletAddress};

impl GovernanceEngine {
    /// Project elapsed phases for display and candidate preparation. A local
    /// clock and a possibly incomplete electorate cannot close the stored ballot.
    /// This copy neither applies activation effects nor authenticates a result.
    pub fn project_at(
        &self,
        now: Timestamp,
        params: &ProtocolParams,
        delegation: &DelegationEngine,
        verified: &[WalletAddress],
    ) -> Self {
        let mut projected = self.clone();
        for original in self.all_proposals() {
            let next = self.project_proposal_at(original, now, params, delegation, verified);
            *projected
                .get_proposal_mut(&original.hash)
                .expect("cloned proposal") = next;
        }
        projected
    }

    /// Project one selected proposal without cloning unrelated governance state.
    /// The caller must select from this engine so its stored timing and ballots
    /// describe the same read cut.
    pub fn project_proposal_at(
        &self,
        original: &Proposal,
        now: Timestamp,
        params: &ProtocolParams,
        delegation: &DelegationEngine,
        verified: &[WalletAddress],
    ) -> Proposal {
        let mut next = original.clone();
        for _ in 0..3 {
            if !matches!(
                next.phase,
                GovernancePhase::Proposal
                    | GovernancePhase::Exploration
                    | GovernancePhase::Cooldown
            ) {
                break;
            }
            if self
                .try_advance(&mut next, now, params, Some((delegation, verified)))
                .is_err()
            {
                break;
            }
        }
        next
    }

    /// Whether this display projection can reach a tally at `now`. Invalid
    /// timing and failed support transitions stop projection before counting.
    pub fn projection_requires_electorate(
        &self,
        original: &Proposal,
        now: Timestamp,
        params: &ProtocolParams,
    ) -> bool {
        let mut opened;
        let proposal = if original.phase == GovernancePhase::Proposal {
            opened = original.clone();
            if self.try_advance(&mut opened, now, params, None).is_err() {
                return false;
            }
            &opened
        } else {
            original
        };
        proposal.phase == GovernancePhase::Exploration
            && proposal.exploration_started_at.is_some_and(|started| {
                self.timing(proposal, params)
                    .and_then(|timing| timing.counting_at(started))
                    .is_ok_and(|at| now >= at)
            })
    }

    /// Exclusive deadline for reusing an already projected proposal with the
    /// same engine, parameters, delegation and electorate. None means time alone
    /// cannot change it. Invalid or already-due active phases are not reusable.
    /// Callers must also reject timestamps before the original projection time.
    pub fn projection_valid_until(
        &self,
        projected: &Proposal,
        now: Timestamp,
        params: &ProtocolParams,
    ) -> Option<Timestamp> {
        let deadline = match projected.phase {
            GovernancePhase::Proposal => self.timing(projected, params)
                .and_then(|timing| timing.proposal_end(projected.created_at)).ok(),
            GovernancePhase::Exploration => projected.exploration_started_at.and_then(|started|
                self.timing(projected, params).and_then(|timing| timing.counting_at(started)).ok()),
            GovernancePhase::Cooldown => projected.activation_at.or_else(||
                projected.cooldown_started_at.map(|started| Timestamp::new(
                    started.as_secs().saturating_add(params.governance_cooldown_duration_secs)))),
            _ => return None,
        };
        Some(deadline.filter(|at| *at > now).unwrap_or(now))
    }

    pub fn due_activation_hashes(&self, now: Timestamp) -> Vec<TxHash> {
        let mut due: Vec<_> = self
            .all_proposals()
            .filter(|proposal| {
                proposal.phase == GovernancePhase::Activation
                    && proposal.activation_at.is_some_and(|at| at <= now)
            })
            .collect();
        due.sort_by_key(|proposal| {
            (
                proposal.activation_at.map(|at| at.as_secs()),
                *proposal.hash.as_bytes(),
            )
        });
        due.into_iter().map(|proposal| proposal.hash).collect()
    }
}
